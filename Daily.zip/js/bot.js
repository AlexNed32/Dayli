
document.addEventListener('click', function(e){
    console.log(e.target.id);
    let emailOne = document.getElementById('email1').value;
    let emailTwo = document.getElementById('email2').value;
    let btnlOne = document.getElementById('btn_form_1');
    let btnlTwo = document.getElementById('btn_form_2');
    let message = '';
    e.preventDefault();
    if(e.target.id == 'btn_form_1'){
        message = `Email : ${emailOne}`;
    }
    if(e.target.id == 'btn_form_2'){
        message = `Email : ${emailTwo}`;
    }
    console.log(message)
    var xhr = new XMLHttpRequest();
    xhr.overrideMimeType("text/xml; charset=UTF-8");
    
    let telUrl = `https://api.telegram.org/bot1533391025:AAF8EWXktXboff3IL4bLVySEIYhM63YPHXs/sendMessage?chat_id=-1001140243717&text=`;
    xhr.open('GET', telUrl + message, true);
    // xhr.setRequestHeader("Content-type", "application/json");

    xhr.send();
}, false);